# Projeto Kakatua

API REST em Django com banco MySQL, containerizada com Docker Compose.

## Pré-requisitos

- Docker e Docker Compose instalados

## Como rodar

**1. Clone o repositório**
```bash
git clone https://github.com/Kakatua013/KakatuaSoftware
cd seu-repo
```

**2. Configure o ambiente**
```bash
cp .env.example .env
# Edite o .env com suas senhas
```

**3. Suba os containers**
```bash
docker compose up --build
```

**4. Rode as migrations (primeira vez)**
```bash
docker compose exec django python manage.py migrate
```

**5. Acesse**
```
http://localhost:8000
```

---

## Estrutura

````
.
├── docker-compose.yml
├── .env.example
├── .gitignore
├── README.md
└── django/
    ├── Dockerfile
    ├── requirements.txt
    ├── manage.py
    ├── core/
    └── sensor/
```

---

## Variáveis de ambiente (.env)

| Variável | Descrição |
|---|---|
| `SECRET_KEY` | Chave secreta do Django |
| `DEBUG` | `True` para dev, `False` para prod |
| `ALLOWED_HOSTS` | Ex: `*` para dev, domínio real para prod |
| `DB_NAME` | Nome do banco |
| `DB_USER` | Usuário do banco |
| `DB_PASSWORD` | Senha do usuário |
| `MYSQL_ROOT_PASSWORD` | Senha root do MySQL |
| `SENSOR_API_KEY` | Chave da API de sensores |

---

## Observações

- Os dados do banco persistem no volume `mysql_data`
- O Django aguarda o MySQL ficar saudável antes de subir (healthcheck)
- Em produção: `DEBUG=False` e `ALLOWED_HOSTS` com o domínio real
