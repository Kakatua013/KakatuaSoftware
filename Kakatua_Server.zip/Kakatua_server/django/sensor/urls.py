from django.urls import path
from . import views

urlpatterns = [
    path('leitura/', views.receber_leitura),
    path('acesso/', views.registrar_acesso),
    path('tranca/<int:id_tranca>/', views.status_tranca),
    path('estacao/', views.estacao_status),
]
