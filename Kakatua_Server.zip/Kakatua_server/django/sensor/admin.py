from django.contrib import admin
from .models import Estacao 

# Se você tiver outras tabelas como Leitura ou Tranca, pode importar e registrar também:
# from .models import Estacao, Leitura, Tranca

admin.site.register(Estacao)

