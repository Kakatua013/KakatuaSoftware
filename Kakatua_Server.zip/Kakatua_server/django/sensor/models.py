from django.db import models


class Leitura(models.Model):
    dispositivo = models.CharField(max_length=50)
    tipo        = models.CharField(max_length=50)
    valor       = models.FloatField()
    unidade     = models.CharField(max_length=20, blank=True)
    criado_em   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-criado_em']


class Tranca(models.Model):
    id_tranca     = models.IntegerField(unique=True)
    estado        = models.CharField(max_length=20)
    reservada     = models.BooleanField(default=False)
    atualizado_em = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Tranca {self.id_tranca} - {self.estado}"


class RegistroAcesso(models.Model):
    login     = models.CharField(max_length=100)
    senha     = models.CharField(max_length=255)
    tranca    = models.ForeignKey(Tranca, on_delete=models.CASCADE)
    criado_em = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.login} -> Tranca {self.tranca.id_tranca}"


class Estacao(models.Model):
    bloqueada     = models.BooleanField(default=False)
    atualizado_em = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Estacao bloqueada={self.bloqueada}"
