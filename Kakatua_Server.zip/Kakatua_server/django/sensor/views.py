from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import json
from .models import Leitura, Tranca, RegistroAcesso, Estacao


def verificar_chave(request):
    chave = request.META.get('HTTP_X_API_KEY', '')
    return chave == settings.SENSOR_API_KEY


@csrf_exempt
def receber_leitura(request):
    if request.method != 'POST':
        return JsonResponse({'erro': 'metodo nao permitido'}, status=405)
    if not verificar_chave(request):
        return JsonResponse({'erro': 'nao autorizado'}, status=401)
    try:
        dados = json.loads(request.body)
        Leitura.objects.create(
            dispositivo=dados.get('dispositivo', 'esp32'),
            tipo=dados['tipo'],
            valor=dados['valor'],
            unidade=dados.get('unidade', ''),
        )
        return JsonResponse({'status': 'ok'})
    except Exception as e:
        return JsonResponse({'erro': str(e)}, status=400)


@csrf_exempt
def registrar_acesso(request):
    if request.method != 'POST':
        return JsonResponse({'erro': 'metodo nao permitido'}, status=405)
    if not verificar_chave(request):
        return JsonResponse({'erro': 'nao autorizado'}, status=401)
    try:
        dados = json.loads(request.body)
        tranca, _ = Tranca.objects.update_or_create(
            id_tranca=dados['id_tranca'],
            defaults={
                'estado': str(dados.get('estado_tranca', 'fechada')),
                'reservada': bool(dados.get('tranca_reservada', False)),
            }
        )
        registro = RegistroAcesso.objects.create(
            login=dados['login'],
            senha=dados['senha'],
            tranca=tranca,
        )
        return JsonResponse({
            'status': 'ok',
            'id_registro': registro.id,
            'tranca': {
                'id': tranca.id_tranca,
                'estado': tranca.estado,
                'reservada': tranca.reservada,
            }
        })
    except Exception as e:
        return JsonResponse({'erro': str(e)}, status=400)


@csrf_exempt
def status_tranca(request, id_tranca):
    if not verificar_chave(request):
        return JsonResponse({'erro': 'nao autorizado'}, status=401)
    try:
        tranca = Tranca.objects.get(id_tranca=id_tranca)
        return JsonResponse({
            'id_tranca': tranca.id_tranca,
            'estado': tranca.estado,
            'reservada': tranca.reservada,
            'atualizado_em': tranca.atualizado_em.isoformat(),
        })
    except Tranca.DoesNotExist:
        return JsonResponse({'erro': 'tranca nao encontrada'}, status=404)


@csrf_exempt
def estacao_status(request):
    # GET — cliente consulta se estacao esta bloqueada
    if request.method == 'GET':
        if not verificar_chave(request):
            return JsonResponse({'erro': 'nao autorizado'}, status=401)
        estacao, _ = Estacao.objects.get_or_create(id=1)
        return JsonResponse({
            'bloqueada': estacao.bloqueada,
            'atualizado_em': estacao.atualizado_em.isoformat(),
        })

    # POST — ESP32 ou teste manual muda o estado
    if request.method == 'POST':
        if not verificar_chave(request):
            return JsonResponse({'erro': 'nao autorizado'}, status=401)
        try:
            dados = json.loads(request.body)
            estacao, _ = Estacao.objects.get_or_create(id=1)
            estacao.bloqueada = bool(dados.get('bloqueada', False))
            estacao.save()
            return JsonResponse({
                'status': 'ok',
                'bloqueada': estacao.bloqueada,
            })
        except Exception as e:
            return JsonResponse({'erro': str(e)}, status=400)

    return JsonResponse({'erro': 'metodo nao permitido'}, status=405)
